import React, { useEffect, useState } from 'react';
import { supabase } from './supabaseClient';
import { useAuth } from './AuthContext.jsx';
import SideModal from './SideModal.jsx';
import { IconPlus, IconEdit, IconTrash } from './Icons.jsx';

const UNIT_OPTIONS = ['mm', 'cm', 'm', 'inch', '-'];

const emptyForm = {
  code: '', barcode: '', name: '', item_desc: '', brand: '', model: '',
  category_id: '', diameter: '', diameter_unit: 'mm', thickness: '', thickness_unit: 'mm',
  length: '', length_unit: 'm', unit: '', min_stock: '', location_id: '',
};

export default function ItemMaster() {
  const { isAdmin } = useAuth();
  const [items, setItems] = useState([]);
  const [categories, setCategories] = useState([]);
  const [locations, setLocations] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [search, setSearch] = useState('');
  const [modalOpen, setModalOpen] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [form, setForm] = useState(emptyForm);
  const [saving, setSaving] = useState(false);
  const [formError, setFormError] = useState('');
  const [pendingDelete, setPendingDelete] = useState(null);

  async function loadAll() {
    setLoading(true);
    setError('');
    const [itemsRes, catRes, locRes] = await Promise.all([
      supabase.from('item_master').select('*, item_categories(name), location_master(location_barcode)').order('code'),
      supabase.from('item_categories').select('*').order('name'),
      supabase.from('location_master').select('*').order('location_barcode'),
    ]);
    if (itemsRes.error) setError(itemsRes.error.message);
    setItems(itemsRes.data || []);
    setCategories(catRes.data || []);
    setLocations(locRes.data || []);
    setLoading(false);
  }

  useEffect(() => { loadAll(); }, []);

  function openCreate() {
    setEditingId(null);
    setForm(emptyForm);
    setFormError('');
    setModalOpen(true);
  }
  function openEdit(item) {
    setEditingId(item.id);
    setForm({
      code: item.code || '', barcode: item.barcode || '', name: item.name || '', item_desc: item.item_desc || '',
      brand: item.brand || '', model: item.model || '', category_id: item.category_id || '',
      diameter: item.diameter || '', diameter_unit: item.diameter_unit || 'mm',
      thickness: item.thickness || '', thickness_unit: item.thickness_unit || 'mm',
      length: item.length || '', length_unit: item.length_unit || 'm',
      unit: item.unit || '', min_stock: item.min_stock ?? '', location_id: item.location_id || '',
    });
    setFormError('');
    setModalOpen(true);
  }

  async function handleSave(e) {
    e.preventDefault();
    if (!form.code.trim() || !form.name.trim()) { setFormError('กรุณากรอก Item Code และชื่อสินค้า'); return; }
    setSaving(true);
    setFormError('');
    const payload = {
      code: form.code.trim(), barcode: form.barcode.trim() || null, name: form.name.trim(),
      item_desc: form.item_desc.trim() || null, brand: form.brand.trim() || null, model: form.model.trim() || null,
      category_id: form.category_id || null,
      diameter: form.diameter.trim() || null, diameter_unit: form.diameter_unit || null,
      thickness: form.thickness.trim() || null, thickness_unit: form.thickness_unit || null,
      length: form.length.trim() || null, length_unit: form.length_unit || null,
      unit: form.unit.trim() || null, min_stock: form.min_stock === '' ? null : Number(form.min_stock),
      location_id: form.location_id || null,
    };
    const query = editingId
      ? supabase.from('item_master').update(payload).eq('id', editingId)
      : supabase.from('item_master').insert(payload);
    const { error } = await query;
    setSaving(false);
    if (error) { setFormError(error.message); return; }
    setModalOpen(false);
    loadAll();
  }

  async function handleDelete(id) {
    if (pendingDelete !== id) { setPendingDelete(id); setTimeout(() => setPendingDelete((p) => (p === id ? null : p)), 3000); return; }
    const { error } = await supabase.from('item_master').delete().eq('id', id);
    if (error) { alert('ลบไม่สำเร็จ: ' + error.message); return; }
    setPendingDelete(null);
    loadAll();
  }

  const filtered = items.filter((it) => {
    const q = search.toLowerCase();
    return !q || it.code?.toLowerCase().includes(q) || it.barcode?.toLowerCase().includes(q) || it.name?.toLowerCase().includes(q);
  });

  return (
    <div>
      <div className="pagehead">
        <div><p className="eyebrow">Item Master</p><h2>ข้อมูลสินค้า</h2><p className="sub">Item Code, Barcode, ประเภท, ขนาด, หน่วยนับ, Minimum Stock และ Location</p></div>
        {isAdmin && <button className="btn" onClick={openCreate}><IconPlus /> เพิ่มสินค้า</button>}
      </div>

      <div className="searchbar">
        <input placeholder="ค้นหา Item Code, Barcode หรือชื่อสินค้า" value={search} onChange={(e) => setSearch(e.target.value)} />
      </div>

      {error && <div className="login-error">โหลดข้อมูลไม่สำเร็จ: {error}</div>}

      <div className="panel" style={{ padding: 0 }}>
        <table>
          <thead><tr><th>Item Code</th><th>ชื่อสินค้า</th><th>ยี่ห้อ / รุ่น</th><th>ประเภท</th><th>ขนาด</th><th>หน่วย</th><th>Min Stock</th><th>Location</th><th></th></tr></thead>
          <tbody>
            {loading ? (
              <tr className="empty-row"><td colSpan={9}>กำลังโหลด...</td></tr>
            ) : filtered.length === 0 ? (
              <tr className="empty-row"><td colSpan={9}>ยังไม่มีข้อมูลสินค้า</td></tr>
            ) : filtered.map((it) => (
              <tr key={it.id}>
                <td className="mono">{it.code}</td>
                <td>{it.name}{it.item_desc && <div style={{ color: 'var(--ink-soft)', fontSize: 12, marginTop: 2 }}>{it.item_desc}</div>}</td>
                <td>{[it.brand, it.model].filter(Boolean).join(' ') || '-'}</td>
                <td>{it.item_categories?.name || '-'}</td>
                <td className="mono">{[
                  it.diameter ? `${it.diameter} ${it.diameter_unit || ''}` : '',
                  it.thickness ? `${it.thickness} ${it.thickness_unit || ''}` : '',
                  it.length ? `${it.length} ${it.length_unit || ''}` : '',
                ].filter(Boolean).join(' × ') || '-'}</td>
                <td>{it.unit || '-'}</td>
                <td className="mono">{it.min_stock ?? '-'}</td>
                <td>{it.location_master?.location_barcode || '-'}</td>
                <td style={{ whiteSpace: 'nowrap' }}>
                  <button className="iconbtn" disabled={!isAdmin} onClick={() => openEdit(it)}><IconEdit /></button>
                  <button className="iconbtn" disabled={!isAdmin} onClick={() => handleDelete(it.id)}>
                    {pendingDelete === it.id ? <span className="mono" style={{ fontSize: 11, fontWeight: 700, color: 'var(--danger)' }}>ยืนยัน?</span> : <IconTrash />}
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <SideModal
        open={modalOpen}
        title={editingId ? 'แก้ไขสินค้า' : 'เพิ่มสินค้าใหม่'}
        onClose={() => setModalOpen(false)}
        footer={<>
          <button className="btn secondary" onClick={() => setModalOpen(false)}>ยกเลิก</button>
          <button className="btn" form="itemForm" type="submit" disabled={saving}>{saving ? 'กำลังบันทึก...' : 'บันทึก'}</button>
        </>}
      >
        <form id="itemForm" onSubmit={handleSave}>
          {formError && <div className="login-error">{formError}</div>}
          <div className="field-row">
            <label className="field"><span className="lbl">Item Code *</span><input required value={form.code} onChange={(e) => setForm({ ...form, code: e.target.value })} /></label>
            <label className="field"><span className="lbl">Barcode</span><input value={form.barcode} onChange={(e) => setForm({ ...form, barcode: e.target.value })} /></label>
          </div>
          <label className="field"><span className="lbl">ชื่อสินค้า *</span><input required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></label>
          <label className="field"><span className="lbl">รายละเอียดสินค้า</span><textarea rows={2} value={form.item_desc} onChange={(e) => setForm({ ...form, item_desc: e.target.value })} /></label>

          <div className="field-row3">
            <label className="field"><span className="lbl">Diameter</span>
              <div style={{ display: 'flex', gap: 6 }}>
                <input style={{ flex: 1.4 }} value={form.diameter} onChange={(e) => setForm({ ...form, diameter: e.target.value })} />
                <select style={{ flex: 1 }} value={form.diameter_unit} onChange={(e) => setForm({ ...form, diameter_unit: e.target.value })}>
                  {UNIT_OPTIONS.map((u) => <option key={u} value={u}>{u}</option>)}
                </select>
              </div>
            </label>
            <label className="field"><span className="lbl">Thickness</span>
              <div style={{ display: 'flex', gap: 6 }}>
                <input style={{ flex: 1.4 }} value={form.thickness} onChange={(e) => setForm({ ...form, thickness: e.target.value })} />
                <select style={{ flex: 1 }} value={form.thickness_unit} onChange={(e) => setForm({ ...form, thickness_unit: e.target.value })}>
                  {UNIT_OPTIONS.map((u) => <option key={u} value={u}>{u}</option>)}
                </select>
              </div>
            </label>
            <label className="field"><span className="lbl">Length</span>
              <div style={{ display: 'flex', gap: 6 }}>
                <input style={{ flex: 1.4 }} value={form.length} onChange={(e) => setForm({ ...form, length: e.target.value })} />
                <select style={{ flex: 1 }} value={form.length_unit} onChange={(e) => setForm({ ...form, length_unit: e.target.value })}>
                  {UNIT_OPTIONS.map((u) => <option key={u} value={u}>{u}</option>)}
                </select>
              </div>
            </label>
          </div>

          <div className="field-row">
            <label className="field"><span className="lbl">ยี่ห้อ</span><input value={form.brand} onChange={(e) => setForm({ ...form, brand: e.target.value })} /></label>
            <label className="field"><span className="lbl">รุ่น</span><input value={form.model} onChange={(e) => setForm({ ...form, model: e.target.value })} /></label>
          </div>

          <label className="field"><span className="lbl">ประเภทสินค้า</span>
            <select value={form.category_id} onChange={(e) => setForm({ ...form, category_id: e.target.value })}>
              <option value="">— ไม่ระบุ —</option>
              {categories.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
            </select>
          </label>

          <div className="field-row">
            <label className="field"><span className="lbl">หน่วยนับ</span><input placeholder="เช่น ชิ้น, เส้น, ม้วน" value={form.unit} onChange={(e) => setForm({ ...form, unit: e.target.value })} /></label>
            <label className="field"><span className="lbl">Minimum Stock</span><input type="number" step="any" value={form.min_stock} onChange={(e) => setForm({ ...form, min_stock: e.target.value })} /></label>
          </div>

          <label className="field"><span className="lbl">Location จัดเก็บ</span>
            <select value={form.location_id} onChange={(e) => setForm({ ...form, location_id: e.target.value })}>
              <option value="">— ไม่ระบุ —</option>
              {locations.map((l) => <option key={l.id} value={l.id}>{l.location_barcode}</option>)}
            </select>
          </label>
        </form>
      </SideModal>
    </div>
  );
}
